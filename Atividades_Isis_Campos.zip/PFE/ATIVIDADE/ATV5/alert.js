alert("Bem Vindo(a)!!")

let  idade = prompt("Qual a sua idade ?");
console.log(idade);

if (idade >= 18) {
    console.log('Maior de idade');
    alert("Maior de idade")
} 
else{
    console.log("Menor de idade ");
    alert("Menor de idade")
    }