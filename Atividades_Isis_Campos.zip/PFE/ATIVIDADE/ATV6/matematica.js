let random = Math.floor(Math.random() * 100) + 1;
console.log(random);

let number = prompt("Digite um numero: ")
let transformer  = parseInt(number)
let conta = Math.sqrt(transformer) 
console.log(conta);