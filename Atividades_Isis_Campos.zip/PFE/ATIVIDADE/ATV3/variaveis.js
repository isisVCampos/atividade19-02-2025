let nome="Anna";
var cargo = "secretaria";
const id ="9805627";
console.log(nome);
console.log(id);
console.log(cargo);

cargo = "supervisora"; 
nome="Anna";
console.log(nome);
console.log(id);
console.log(cargo);

if (true ) {
    let telefone = 97583633
}
    console.log(telefone); 
