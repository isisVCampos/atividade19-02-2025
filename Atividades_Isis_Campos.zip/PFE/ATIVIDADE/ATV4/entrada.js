let nome = prompt("Digite seu nome")
console.log(nome);
let numero1 = prompt("qual seu numero")
let numero2 = prompt("qual seu numero")
let conta =parseInt(numero1)+ parseInt(numero1)

console.log(conta);
