let nome="Joana";
console.log(nome);
console.log(`O meu nome é: ${nome}`);

let laranjas = 5;
console.log(laranjas * laranjas);

nome = "joão";
console.log(nome);

laranjas= 8974;
console.log(laranjas);

let um = 1, dois = 2, tres = 3;
console.log(um, dois, tres);
let t1 = 'ola ', t2 = 'pessoal';
console.log(t1 + t2);

console.log(um, dois, tres);