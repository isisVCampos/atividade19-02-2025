let x = 0;
let y = 0;
if (x == 0 && y == 0) {
    let x = 5;
    if (x > 2) {
        console.log(z);
        for (i = 0; i < 5; i = i + 1){
            console.log(i);
            if (i == 2) {
                console.log("i é = 2");
                
            }
        }
        
    }
    
}