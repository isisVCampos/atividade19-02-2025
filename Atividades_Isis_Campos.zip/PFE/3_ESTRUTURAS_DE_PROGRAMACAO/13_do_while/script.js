let x = 100;
do{ //faça
    console.log(x/2);
X = X - 5;
} while(x >= 0);//enquanto