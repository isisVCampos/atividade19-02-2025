let nome3 = 'teste';
let $nome = 'teste2';
console.log($nome);

let_nome = 'teste3';
console.log(let_nome);

