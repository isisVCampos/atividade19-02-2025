let nome = "juca";
let idade = 28;

if (nome !=undefined && nome == "joaquim")  {
    console.log("Nome esta definido!");
    
}

else if (nome != undefined && nome.length > 5 && idade == 50) {
console.log("Meu nome é juca");    
}
else{
console.log("não é o juca ");
}