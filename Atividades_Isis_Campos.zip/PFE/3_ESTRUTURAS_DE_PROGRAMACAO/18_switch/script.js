let esc = prompt("Escolha algo do cardapio")

let nome ="Lanche";
switch(esc) {
   case "Lanche":
      console.log("Escolheu lanche");
      break;
      case "Pizza":
         console.log("Escolheu pizza");
         break;
         case "Brigadeiro":
         console.log("Escolheu brigadeiro");
         break;
         default:
            console.log("Não encontrei nada do que gosto");
break
         }