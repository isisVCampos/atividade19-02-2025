let  idade = prompt("Qual a sua idade ?");
let nome = prompt("Digite seu nome")
console.log(idade);
console.log(nome);

