var nome = "Bastião";
const ip ="127.0.0.1"; //host local
const pi = 3.14;
console.log(nome);
console.log(ip);
console.log(pi);

