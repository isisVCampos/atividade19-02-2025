let idade = 18;
if (idade==18) {
    console.log("A idade é 18");
}
if (idade > 25) {
    console.log("idade maior que 25");
}
let nome="Lucas";
if (nome == "Lucas" && idade > 25) {
    console.log('Liberado!');
}

let passaporte = true;
if (nome == "Lucas" && idade > 30 || passaporte == true){
    console.log("Liberado 2!!");
} {
    
}