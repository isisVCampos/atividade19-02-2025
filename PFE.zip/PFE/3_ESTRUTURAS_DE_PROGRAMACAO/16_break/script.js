let nome = "josé";
for(let i = 0; i < 10; i ++){
    if(i == 3){
        nome == "joao";
    }
    if (i == 5 && nome == "joao") {
        console.log("O nome é joao, pode parar!");
        break;
        
    }
}
