for ( let vassoura = 0; vassoura < 100; vassoura ++){
    console.log(`A soma das posiçoes da vassoura é: ${vasssoura}`);}