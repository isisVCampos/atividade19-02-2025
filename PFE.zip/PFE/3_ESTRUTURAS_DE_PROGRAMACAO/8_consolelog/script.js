let idade = 26;
let nome = "wesley";
console.log(nome);
console.log(idade);
console.log(`O meu nome é ${nome}, tenho ${idade} anos`);