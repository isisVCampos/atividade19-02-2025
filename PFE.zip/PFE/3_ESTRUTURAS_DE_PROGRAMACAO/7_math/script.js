let maior = Math.max(6, 12, 20, 50, 100);
console.log(maior);

let menor = Math.min(1, 4, 19, 100, 90);
console.log(menor);

let arredondar = Math.round(3.14151926);
console.log(arredondar);

let arredondar_cima = Math.ceilo(5.75);
console.log(arredondar_cima);

let arredondar_baixo = Math.floor(3.11);
console.log(arredondar_baixo);